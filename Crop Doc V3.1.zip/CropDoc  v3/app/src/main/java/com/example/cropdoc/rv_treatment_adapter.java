package com.example.cropdoc;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class rv_treatment_adapter extends RecyclerView.Adapter<treatment_holder> {
    private String disease_name[];
    private Context context;

    public rv_treatment_adapter(String[] disease_name, Context context) {
        this.disease_name = disease_name;
        this.context = context;
    }

    @NonNull
    @Override
    public treatment_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View view=layoutInflater.inflate(R.layout.card_item_1,parent,false);
        return new treatment_holder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull treatment_holder holder, @SuppressLint("RecyclerView") int position) {
      //  holder.cv.setCardBackgroundColor(context.getColor(R.color.treatment));
        holder.c_tv.setText(disease_name[position].toString());
        holder.cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent=new Intent(context,description.class);
              //  intent.putExtra("value",)
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return disease_name.length;
    }
}

class treatment_holder extends RecyclerView.ViewHolder{
    TextView c_tv;
    CardView cv;
    public treatment_holder(@NonNull View itemView) {
        super(itemView);
        cv=itemView.findViewById(R.id.cv1);
        c_tv=itemView.findViewById(R.id.cardViewText1);
    }
}
