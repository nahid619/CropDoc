package com.example.cropdoc;

import static android.app.PendingIntent.getActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class result extends AppCompatActivity {
ImageView image;
TextView disease;
TextView crop;
TextView confidence;
CardView back;

Button treatment;
Button rescan;

Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        image = findViewById(R.id.imageView2);
        disease = findViewById(R.id.tv_result_disease);
        confidence = findViewById(R.id.tv_result_confidence);

        rescan=findViewById(R.id.button2);
        treatment=findViewById(R.id.button);
        crop=findViewById(R.id.textView3);

        back=findViewById(R.id.cardView2);

        image.setImageBitmap(data.image);
        disease.setText(data.identified_disease);
        crop.setText(data.selected_crop);
        confidence.setText(String.valueOf(data.confidence));

        context=result.this;

        if(data.identified_disease.equals("Invalid")){
            treatment.setVisibility(View.INVISIBLE);
        }
        else if(data.identified_disease.equals("Healthy")){
            treatment.setVisibility(View.INVISIBLE);
        }

        rescan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        treatment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,description.class);
                String trt[];
                String res = null;



                switch (data.selected_crop){
                        case "Corn":
                            trt=getResources().getStringArray(R.array.disease_trmt);
                            res=trt[findIndex(data.identified_disease,data.disease_name)];

                        break;

                        case "Potato":
                            trt=getResources().getStringArray(R.array.disease_trmt_1);
                            res=trt[findIndex(data.identified_disease,data.disease_name)];

                            break;

                        case "Rice":
                            trt=getResources().getStringArray(R.array.disease_trmt_2);
                            res=trt[findIndex(data.identified_disease,data.disease_name)];

                            break;

                        case "Wheat":
                            trt=getResources().getStringArray(R.array.disease_trmt_3);
                            res=trt[findIndex(data.identified_disease,data.disease_name)];

                            break;
                }


                intent.putExtra("d",res);
                intent.putExtra("disease",data.selected_crop);

                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }
    public int findIndex(String input,String[] sol) {
        String[] solution=sol;
        for (int i = 0; i < solution.length; i++) {
            if (solution[i].equalsIgnoreCase(input)) {
                return i;

            }
        }
        return 0;
    }
}




